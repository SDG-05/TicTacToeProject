import javax.swing.*;
import java.awt.*;
import java.sql.*;

public class Main {
    public static void main(String[] args) {
        View login = new View();
        login.LoginView();
    }
}

